import json
import boto3
import logging
import datetime
import os
from datetime import datetime, timedelta

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def get_alarm(alarm_name):
    try:    
        cloudwatch = boto3.client('cloudwatch')
        response = cloudwatch.describe_alarms(
        AlarmNames=[
            alarm_name,
        ]
        )
        return response
    except Exception as e:
        logger.error(e)
    

def create_ec2_alarm(instance_id, metric_name,threshold_type,threshold,period_time,evaluation_periods_terms,namespace,statistic):
    try:
        cloudwatch = boto3.client('cloudwatch')
        comparison_operator="GreaterThanOrEqualToThreshold"
        if threshold_type == "ThresholdLow":
            comparison_operator="LessThanOrEqualToThreshold"
        alarm_name="EC2-"+threshold_type+"-"+metric_name+"-"+str(instance_id)+"-Alarm"
        response = get_alarm(alarm_name)
        
        dimensions = [{'Name': 'InstanceId','Value':instance_id}]
        
        if metric_name == "DiskUtilization":
            dimensions = [{'Name': 'InstanceId','Value':instance_id},{'Name': 'Partition','Value':'/'}]
       
        
        if len (response['MetricAlarms']) == 0 or response['MetricAlarms'][0]['Threshold'] != threshold or response['MetricAlarms'][0]['Period'] != period_time:
            cloudwatch.put_metric_alarm(
            AlarmName=alarm_name,
            AlarmDescription='Alarm when server CPU exceeds or below threshold :',
            ActionsEnabled=True,
            MetricName=str(metric_name),
            AlarmActions=[
               os.environ['SNS_ARN']
            ],
            Namespace=namespace,
            Period=period_time,
            Statistic=statistic,
            EvaluationPeriods=evaluation_periods_terms,
            Threshold=threshold,
            ComparisonOperator=comparison_operator,            
            Dimensions=dimensions
            )
    except Exception as e:
        logger.error(e)


def get_ec2_instance_list():    
    try:
        client = boto3.client('ec2')
        instDict=client.describe_instances()        
        hostList = {}
        for r in instDict['Reservations']:
            for inst in r['Instances']:
                node_name=""
                if inst['State']['Name'] == "running":
                    for tag in inst['Tags']:
                        if tag['Key'] == 'Name':
                            node_name=tag['Value']
                    key=inst['InstanceId']        
                hostList[key] =  node_name                  
        return hostList
    except Exception as e:
        logger.error(e)


def trigger_handler(event, context):
    try:        
        s3 = boto3.client('s3')
        obj = s3.get_object(Bucket=os.environ['S3_Bucket'], Key='lambda/metrics-json.json')
        all_merics = json.loads(obj['Body'].read())
        list=get_ec2_instance_list()
        for instance_id,node_name in list.iteritems():
            ec2_metrics=all_merics['EC2_Metrics']
            for row in all_merics['EC2_Metrics']:
                if row['ExecuteHigh']:
                    logger.info("For Ec2 node : %s instance-id : %s creating cloud-watch %s alarm" %(node_name,instance_id,row[u'MetricsName']))
                    logger.info("Threshold hight : %s" %(row[u'ThresholdHigh']))
                    create_ec2_alarm(instance_id,row['MetricsName'],'High',row['ThresholdHigh'],row['PeriodHigh'],row['EvaluationHigh'],row['Namespace'],row['UnitHigh'])
                if row['ExecuteLow']:  
                    logger.info("For Ec2 node : %s instance-id : %s creating cloud-watch %s alarm" %(node_name,instance_id,row[u'MetricsName']))
                    logger.info("Threshold hight : %s Threshold Low : %s " %(row[u'ThresholdHigh'],row[u'ThresholdLow']))
                    create_ec2_alarm(instance_id,row['MetricsName'],'ThresholdLow',row['ThresholdLow'],row['PeriodLow'],row['EvaluationLow'],row['Namespace'],row['UnitLow'])
    except Exception as e:
        logger.error(e)