# CF Templates for AWS Resource monitoring Lambda Functions 
## Prerequisite

Create SNS Topic manually and pass that ARN in lambda function.

Upload above lambda functions zip in s3 bucket insid lambda folder and pass this s3 bucket name as CF template parameter.

Upload metrics-json.json file in s3 bucket inside lambda folder. This Json file has metrics list which you want to execute. 

### CF Template parameters
   
<br>

```
AlarmNotificationTopicARN (SNS Topic ARN)
LambdaExecutionIAMRole (IAM Role which have permission for execute Lambda function)
S3BucketName (Bucket name where lambda function uploaded)
Email (Optional)
```	