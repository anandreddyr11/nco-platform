#!/bin/bash

#-------------------------------------------------------------------------------
# Manually entered constants (not required if using EC2 IAM Roles).
#-------------------------------------------------------------------------------
# The first time the script runs, if EC2 IAM Roles are not in use, the AWS
# credential files will be created if these three values are not blank.
#
# During execution, the access key and secret key value will be removed from
# the script allowing future executions to ultilize the profile.
#
# ACCESSKEY: AWS Access Key
# SECRETKEY: AWS Secret Key 
# PROFNAME:  Profile name which already holds an access key and secret or
#            profile name to store the access key and secret key from this
#            script.
#-------------------------------------------------------------------------------
ACCESSKEY=""
SECRETKEY=""
PROFNAME=""
#-------------------------------------------------------------------------------
# Constants
#-------------------------------------------------------------------------------
   #----------------------------------------------------------------------------
   # URLs
   #----------------------------------------------------------------------------
   IDENTITY="http://169.254.169.254/latest/dynamic/instance-identity"
   METADATA="http://169.254.169.254/latest/meta-data"
   #----------------------------------------------------------------------------
   # Files
   #----------------------------------------------------------------------------
   DEVNULL="/dev/null"
   MEMINFO="/proc/meminfo"
   #----------------------------------------------------------------------------
   # Values
   #----------------------------------------------------------------------------
   DEFCODE=0
   NOAWS=9996
   NOCREDS=9997
#-------------------------------------------------------------------------------
# Variables
#-------------------------------------------------------------------------------
iId=$(curl -s ${METADATA}/instance-id)
iRegion=$(curl -s ${IDENTITY}/document | grep -i "region" | awk -F'"' '{print $(NF - 1)}')
msgCode=${DEFCODE}
retVal=''
#-------------------------------------------------------------------------------
# Hash Tables
#-------------------------------------------------------------------------------
declare -A usrInfo

#-------------------------------------------------------------------------------
# Call all other functions.
#-------------------------------------------------------------------------------
Main()
   {
   #----------------------------------------------------------------------------
   # Download and install the AWS CLI Tools, if they are not present.
   #----------------------------------------------------------------------------
   [ ! -x /usr/bin/aws ] && InstallAWSCLITools
   #----------------------------------------------------------------------------
   # Continue on if the AWS CLI Tools installed succesfully.
   #----------------------------------------------------------------------------
   if [ ${msgCode} -eq ${DEFCODE} ]
   then
      GetAuthString
      #----------------------------------------------------------------------
      # If no errors, record the data and send to CloudWatch.
      #----------------------------------------------------------------------
      if [ ${msgCode} -eq ${DEFCODE} ]
      then
         DiskUtilization
         MemoryUtilization
      fi
   fi
   #----------------------------------------------------------------------------
   # If non-argument errors exist, display the associated error message. 
   #----------------------------------------------------------------------------
   [ ${msgCode} -gt ${DEFCODE} ] && DisplayMessage ${msgCode}
   #----------------------------------------------------------------------------
   # Exit the script passing the msgCode as the script status. 
   #----------------------------------------------------------------------------
   ExitScript ${msgCode}
   }

#-------------------------------------------------------------------------------
# Install the AWS CLI tools.
#-------------------------------------------------------------------------------
InstallAWSCLITools()
   {
   verComp=${DEFCODE}

   if [ -x /usr/bin/aws ]
   then
      cliVer=$(aws --version less 2>&1 | awk -F'aws-cli/' '{print $NF}' | awk '{print $1}' | tr '.' ' ')
      newVer=$(curl -s https://aws.amazon.com/releasenotes/CLI | grep "Release: " | awk -F'Release: ' '{print $NF}' | awk -F'<' '{print $1}' | awk '{print $NF}' | sort -t. -k1,1n -k2,2n -k3,3n -k4,4n | tail -1 | tr '.' ' ')

      arrCliVer=(${cliVer})
      arrNewVer=(${newVer})

      for ((i = ${DEFCODE}; i < ${#arrCliVer[@]}; i++))
      do
         [ ${arrNewVer[${i}]} -gt ${arrCliVer[${i}]} ] && verComp=1
      done
   fi

   if [ ${verComp} -gt ${DEFCODE} ] || [ ! -x /usr/bin/aws ]
   then
      [ ! -d ${DOWNLOADS} ] && mkdir -pm 0750 ${DOWNLOADS}
      [ -f ${DOWNLOADS}/awscli-bundle.zip ] && rm -f ${DOWNLOADS}/awscli-bundle.zip
      [ -d ${DOWNLOADS}/awscli-bundle ] && rm -rf ${DOWNLOADS}/awscli-bundle

      curl -s https://s3.amazonaws.com/aws-cli/awscli-bundle.zip -o ${DOWNLOADS}/awscli-bundle.zip

      fileSize=$(stat -c "%s" ${DOWNLOADS}/awscli-bundle.zip)

      [ ${fileSize} -gt ${DEFCODE} ] && unzip -q -o ${DOWNLOADS}/awscli-bundle.zip -d ${DOWNLOADS}
      [ -d ${DOWNLOADS}/awscli-bundle ] && ${DOWNLOADS}/awscli-bundle/install -i /usr/local/aws -b /usr/bin/aws >${DEVNULL} 2>&1

      chmod 0750 /usr/local/aws/bin/aws*
   fi
   }

#-------------------------------------------------------------------------------
# Determine if EC2 IAM profile or access/secret key authentication will be used.
#-------------------------------------------------------------------------------
GetAuthString()
   {
   retVal=$(aws ec2 describe-instances --region ${iRegion} --instance ${iId} 2>&1 >${DEVNULL})
   theArgs=''

   if [ -z "${retVal}" ]
   then
      usrInfo=( [region]="${iRegion}" )
   else
      [ ! -z "${PROFNAME}" ] && retVal=$(aws ec2 describe-instances --profile ${PROFNAME} --region ${iRegion} --instance ${iId} 2>&1 >${DEVNULL})

      if [ "${retVal}" == '' ]
      then
         usrInfo=( [region]="${iRegion}" [profile]="${PROFNAME}" )
      else
         if [ ! -z "${PROFNAME}" ] && [ ! -z "${ACCESSKEY}" ] && [ ! -z "${SECRETKEY}" ]
         then
            [ ! -d /root/.aws ] && mkdir -m 0700 /root/.aws

            isProfile=$(grep "${PROFNAME}" /root/.aws/* 2>${DEVNULL} | wc -l)

            if [ ${isProfile} -eq ${DEFCODE} ]
            then
               printf "[profile ${PROFNAME}]
                       output = table
                       region = ${iRegion}
                       " >>/root/.aws/config && chmod 0600 /root/.aws/config && sed -i "s/                    //" /root/.aws/config

               printf "[${PROFNAME}]
                       aws_access_key_id = ${ACCESSKEY}
                       aws_secret_access_key = ${SECRETKEY}
                       " >>/root/.aws/credentials && chmod 0600 /root/.aws/credentials && sed -i "s/                    //" /root/.aws/credentials
            fi

            retVal=$(aws ec2 describe-instances --profile ${PROFNAME} --region ${iRegion} --instance ${iId} 2>&1 >${DEVNULL})
            [ -z "${retVal}" ] && usrInfo=( [region]="${iRegion}" [profile]="${PROFNAME}" )
         fi
      fi
   fi

   for i in "${!usrInfo[@]}"
   do
      theArgs+="--${i} ${usrInfo[${i}]} "
   done

   sed -i 's/^ACCESSKEY=.*/ACCESSKEY=\"\"/g' $0
   sed -i 's/^SECRETKEY=.*/SECRETKEY=\"\"/g' $0

   [ ! -z "${retVal}" ] && msgCode=${NOCREDS}
   }

#-------------------------------------------------------------------------------
# Determine disk usage and send to CloudWatch.
#-------------------------------------------------------------------------------
DiskUtilization()
   {
   thePartitions=$(df -lh | awk '{print $NF"\t"$(NF - 1)}' | egrep -ve"^[a-z|A-Z]|^\/dev|^\/run|^\/sys|^\/mnt")

   IFS=$'\n'

   for i in ${thePartitions}
   do
      thePart=$(echo ${i} | awk '{print $1}')
      theVal=$(echo ${i} | awk '{print $NF}' | awk -F'%' '{print $1}')

      eval aws cloudwatch put-metric-data ${theArgs}--namespace 'InstanceResources' --metric-name DiskUtilization --unit=Percent --dimensions "InstanceId=${iId},Partition=${thePart}" --value ${theVal}
   done
   }

#-------------------------------------------------------------------------------
# Determine memory usage and send to CloudWatch.
#-------------------------------------------------------------------------------
MemoryUtilization()
   {
   memTotal=$(grep "^MemTotal" /proc/meminfo | awk '{print $2}')
   memFree=$(grep "^MemFree" /proc/meminfo | awk '{print $2}')
   memBuffers=$(grep "^Buffers" /proc/meminfo | awk '{print $2}')
   memCached=$(grep "^Cached" /proc/meminfo | awk '{print $2}')
   freeMem=$((${memFree} + ${memBuffers} + ${memCached}))
   usedMem=$((${memTotal} - ${freeMem}))
   memPercent=$(awk "BEGIN { pc=100*${usedMem}/${memTotal}; i=int(pc); print (pc-i<0.5)?i:i+1 }")

   eval aws cloudwatch put-metric-data ${theArgs}--namespace 'InstanceResources' --metric-name MemoryUtilization --unit=Percent --dimensions "InstanceId=${iId}" --value ${memPercent}
   }

#-------------------------------------------------------------------------------
# Display messages to standard out.
#-------------------------------------------------------------------------------
DisplayMessage()
   {
   case ${1} in
      ${NOAWS})   printf "\'AWS CLI Tools\' not found on this server!\n";;
      ${NOCREDS}) printf "${retVal}\n";;
   esac
   }

#-------------------------------------------------------------------------------
# Exit the script.
#-------------------------------------------------------------------------------
ExitScript()
   {
   exit ${1}
   }

#-------------------------------------------------------------------------------
# Execute the Main function.
#-------------------------------------------------------------------------------
Main
