import json
import boto3
import logging
import datetime
import os
from datetime import datetime, timedelta

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_alarm(alarm_name):
	try:
		cloudwatch = boto3.client('cloudwatch')
		response = cloudwatch.describe_alarms(
			AlarmNames=[
				alarm_name,
				]
			)
		return response
	except Exception as e:
		logger.error(e)

def create_elb_alarm(instance_identifier, metric_name,threshold_type,threshold,period_time,evaluation_periods_terms,namespace,statistic,loadbalancername):
	try:
		cloudwatch = boto3.client('cloudwatch')
		comparison_operator="GreaterThanOrEqualToThreshold"
		if threshold_type == "ThresholdLow":
			comparison_operator="LessThanOrEqualToThreshold"
		load_balancer=instance_identifier.split("loadbalancer/")[1]
		alarm_name="ELB-"+loadbalancername+threshold_type+"-"+metric_name+"-Alarm"
		response = get_alarm(alarm_name)
		if len (response['MetricAlarms']) == 0 or response['MetricAlarms'][0]['Threshold'] != threshold or response['MetricAlarms'][0]['Period'] != period_time:
			cloudwatch.put_metric_alarm(
			AlarmDescription="Alarm when server "+metric_name+" exceeds threshold :",
			AlarmName=alarm_name,
			ActionsEnabled=True,
			MetricName=str(metric_name),
			AlarmActions=[
				os.environ['SNS_ARN']
			],
			Namespace=namespace,
			Period=period_time,
			Statistic=statistic,
			EvaluationPeriods=evaluation_periods_terms,
			Threshold=threshold,
			ComparisonOperator=comparison_operator,            
			Dimensions=[
				{
				'Name': 'LoadBalancer',
				'Value': load_balancer
				}
			]
			)
		else:
			print "No need to change"
	except Exception as e:
		print e
		logger.error(e)


def elb_list():
	try:
		elbList = boto3.client('elbv2')
		balancer_list = elbList.describe_load_balancers()
		return balancer_list
	except Exception as e:
		logger.error(e)


def trigger_handler(event, context):
	try:
		s3 = boto3.client('s3')
		obj = s3.get_object(Bucket=os.environ['S3_Bucket'], Key='lambda/metrics-json.json')
		all_merics = json.loads(obj['Body'].read())
		bls_list=elb_list()
		for bls in bls_list['LoadBalancers']:
			elb_metrics=all_merics['ApplicationELB_Metrics']
			for row in all_merics['ApplicationELB_Metrics']:
				if row['ExecuteHigh']:
					create_elb_alarm(bls['LoadBalancerArn'],row['MetricsName'],'ThresholdHigh',row['ThresholdHigh'],row['PeriodHigh'],row['EvaluationHigh'],row['Namespace'],row['UnitHigh'],bls['LoadBalancerName'])
					logger.info("For LoadBalancer : %s creating cloud-watch %s alarm" %(bls['LoadBalancerName'],row[u'MetricsName']))
					logger.info("Threshold hight : %s" %(row[u'ThresholdHigh']))
				if row['ExecuteLow']:
					create_elb_alarm(bls['LoadBalancerArn'],row['MetricsName'],'ThresholdLow',row['ThresholdLow'],row['PeriodLow'],row['EvaluationLow'],row['Namespace'],row['UnitLow'],bls['LoadBalancerName'])
	except Exception as e:
		logger.error(e)