#!/bin/bash


PATH="/var/local/cloudwatch"
FILENAME="CustomCloudWatch.bash"
CMSCRIPTURL="https://s3.amazonaws.com/nuxeo-platform/lambda/$FILENAME"
if [ ! -d "$PATH" ]
then
    /bin/mkdir -p "$PATH"
fi

/usr/bin/wget $CMSCRIPTURL -O "$PATH/$FILENAME"

echo  "*/5 * * * * root bash -x $PATH/$FILENAME  > $PATH/CustomCloudWatch.log 2>&1" > /etc/cron.d/monitor-system
#echo '*/5 * * * * /bin/bash -x $PATH/$FILENAME >> $PATH/CustomCloudWatch.log 2>&1' | crontab -