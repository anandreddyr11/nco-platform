import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

#Getting alarm list
def get_alarm_list(token):
    try:
        client = boto3.client('cloudwatch')
        if token == "":
            response = client.describe_alarms()
        else:
            response = client.describe_alarms(
                NextToken=token
            )
        return response
    except Exception as e:
        logger.error(e)

# checking  EC2 instances 
def ec2_alarm(global_list):
    try:
        aws_type='EC2'
        for g_list in global_list:
            if g_list.startswith(aws_type):
                alarm_id=""
                id_list=g_list.split('-')
                print id_list
                alarm_id= id_list[3]+"-"+id_list[4]
                id_response=check_ec2_instance(alarm_id,aws_type)
                if id_response['InstanceStatuses'] == []:
                    print ('Instance terminated, Alarm deleted')
                    delete_alarm(g_list)
                else:
                    print("Alarm is not deleted ,Instance is still running")
    except Exception as e:
        logger.error(e)
                                   
                   
# checking  instances 
def check_ec2_instance(alarm_id,aws_type):
    try:
        if aws_type == 'EC2':
            client = boto3.client('ec2')
            response=client.describe_instance_status(
                InstanceIds=[alarm_id]
            )
        return response
    except Exception as e:
        logger.error(e)


#getting list of RDS/ELB/AutoScaling
def check_list(aws_type):
    try:
        if aws_type=='RDS':
            client = boto3.client('rds')
            response = client.describe_db_instances()
        if aws_type=='ELB':
            client = boto3.client('elbv2')
            response = client.describe_load_balancers()
        if aws_type=='AutoScaling':
            client = boto3.client('autoscaling')
            response = client.describe_auto_scaling_groups()
        
        return response
    except Exception as e:
        logger.error(e)


# checking RDS Alarms 
def rds_alarm(global_list):
    try:
        aws_type='RDS'
        ds_list=[]
        rds_alarm_id={}
        boolean= False 
        id_list=check_list(aws_type)
        
        client = boto3.client('cloudwatch')
        
        for i in id_list['DBInstances']:
            ds_list.append(i['DBInstanceIdentifier'])
        
        for g_list in global_list:
            if g_list.startswith(aws_type):
                response = client.describe_alarms(
                    AlarmNames=[g_list]
                    )
                for rds_dimension in response['MetricAlarms']:
                    for rds_value in rds_dimension['Dimensions']:
                        key=rds_dimension['AlarmName']
                        rds_alarm_id[key]=rds_value['Value']
                   
        for rds in rds_alarm_id:
            if rds_alarm_id[rds] in ds_list:
                print rds_alarm_id[rds]+"  database present"
                boolean=False
            else:
                boolean=True
                print rds_alarm_id[rds]+"  database is not present"
            if boolean:
                delete_alarm(rds)
    except Exception as e:
        logger.error(e)

# checking ELB Alarms 
def elb_alarm(global_list):
    try:
        aws_type='ELB'
        lb_list=[]
        elb_alarm_id={}
        boolean= False 
        id_list=check_list(aws_type)
    
        client = boto3.client('cloudwatch')
        
        for res in id_list['LoadBalancers']:
            lb_list.append((res['LoadBalancerArn']).split("loadbalancer/")[1])
        for g_list in global_list:
            if g_list.startswith(aws_type):
                response = client.describe_alarms(
                    AlarmNames=[g_list]
                    )
                for elb_dimension in response['MetricAlarms']:
                    for elb_value in elb_dimension['Dimensions']:
                        key=elb_dimension['AlarmName']
                        elb_alarm_id[key]=elb_value['Value']
        
        for elb in elb_alarm_id:
            if elb_alarm_id[elb] in lb_list:
                print elb_alarm_id[elb]+"  loadBalancer present"
                boolean=False
            else:
                boolean=True
                print elb_alarm_id[elb]+"  loadBalancer is not present"
            if boolean:
                delete_alarm(elb)
    except Exception as e:
        logger.error(e)

#Autoscaling alarms
def autoscaling_alarm(global_list):
    try:
        aws_type='AutoScaling'
        as_list=[]
        scale_alarm_id={}
        boolean= False 
        id_list=check_list(aws_type)
        
        client = boto3.client('cloudwatch')
         
        for i in id_list['AutoScalingGroups']:
            as_list.append(i['AutoScalingGroupName'])
        for g_list in global_list:
            if g_list.startswith(aws_type):
                response = client.describe_alarms(
                    AlarmNames=[g_list]
                    )
                for as_dimension in response['MetricAlarms']:
                    for as_value in as_dimension['Dimensions']:
                        key=as_dimension['AlarmName']
                        scale_alarm_id[key]=as_value['Value']
                        
        for auto in scale_alarm_id:
            if scale_alarm_id[auto] in as_list:
                print scale_alarm_id[auto]+"  AutoScaleGroup present"
                boolean=False
            else:
                boolean=True
                print scale_alarm_id[auto]+"  AutoScaleGroup is not present"
            if boolean:
                delete_alarm(auto)
    except Exception as e:
        logger.error(e)
        
#Deleting Alarms
def delete_alarm(alarm):
    try:
        client = boto3.client('cloudwatch')
        response = client.delete_alarms(
                AlarmNames=[alarm]
            )
    except Exception as e:
        logger.error(e)
    
    
def trigger_handler(event, context):
    try:
        client = boto3.client('cloudwatch')
        next_token = "" # not necessa[]
        global_list = []
        while True: 
            list=get_alarm_list(next_token)
            for list_a in list['MetricAlarms']:
                global_list.append(list_a['AlarmName'])
            if 'NextToken' in list.keys():
                next_token=list['NextToken']
            else:
                break
        ec2_alarm(global_list)
        rds_alarm(global_list)
        elb_alarm(global_list)
        autoscaling_alarm(global_list)
    except Exception as e:
        logger.error(e)