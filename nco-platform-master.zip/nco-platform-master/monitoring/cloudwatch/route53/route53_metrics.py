import json
import boto3
import logging
import datetime
import os
from datetime import datetime, timedelta

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_alarm(alarm_name):
    try:
        cloudwatch = boto3.client('cloudwatch')
        response = cloudwatch.describe_alarms(
        AlarmNames=[
            alarm_name,
        ]
        )
        return response
    except Exception as e:
        logger.error(e)

def route53_alarm(instance_id, metric_name,threshold_type,threshold,period_time,evaluation_periods_terms,namespace,statistic):
    try:
        cloudwatch = boto3.client('cloudwatch')
        comparison_operator="GreaterThanOrEqualToThreshold"
        if threshold_type == "ThresholdLow":
            comparison_operator="LessThanOrEqualToThreshold"
        alarm_name="Route53 Healthcheck-"+str(instance_id)+"-"+threshold_type+"-"+metric_name+"-Alarm"
        response = get_alarm(alarm_name)
        dimensions = [{'Name': 'HealthCheckId','Value':instance_id}]
       
        if len (response['MetricAlarms']) == 0 or response['MetricAlarms'][0]['Threshold'] != threshold or response['MetricAlarms'][0]['Period'] != period_time:
            cloudwatch.put_metric_alarm(
            AlarmName=alarm_name,
            AlarmDescription='Alarm when server Route53 HealthCheck exceeds or below threshold :',
            ActionsEnabled=True,
            MetricName=str(metric_name),
            AlarmActions=[
               os.environ['SNS_ARN']
            ],
            Namespace=namespace,
            Period=period_time,
            Statistic=statistic,
            EvaluationPeriods=evaluation_periods_terms,
            Threshold=threshold,
            ComparisonOperator=comparison_operator,            
            Dimensions=dimensions
            )
    except Exception as e:
        logger.error(e)

def host_list():
    try:
        client = boto3.client('route53')
        h_list=[]
        response = client.list_health_checks()
        for r in response['HealthChecks']:
            print h_list.append(r['Id'])
            
        return h_list
    except Exception as e:
        logger.error(e)
    
def trigger_handler(event, context):
    try:
        s3 = boto3.client('s3')
        obj = s3.get_object(Bucket='nuxeo-platform', Key='lambda/metrics-json.json')
        all_metrics = json.loads(obj['Body'].read())
        h_list=host_list()
        scaling_metrics=all_metrics['Route53_Metrics']
        for h in h_list:
            for row in all_metrics['Route53_Metrics']:
                if row['ExecuteHigh']:
                    logger.info("For CloudFront : %s  creating cloud-watch %s alarm" %(h,row[u'MetricsName']))
                    logger.info("Maximum Size : %s Minimum Size : %s "  %(row['ThresholdHigh'],row['ThresholdLow']))
                    route53_alarm(h,row['MetricsName'],'High',row['ThresholdHigh'],row['PeriodHigh'],row['EvaluationHigh'],row['Namespace'],row["UnitHigh"])
                if row['ExecuteLow']:
                    logger.info("For CloudFront : %s  creating cloud-watch %s alarm" %(h,row[u'MetricsName']))
                    logger.info("Minimum Size : %s Minimum Size : %s " %(row['ThresholdHigh'],row['ThresholdLow']))
                    route53_alarm(h,row['MetricsName'],'ThresholdLow',row['ThresholdHigh'],row['PeriodHigh'],row['EvaluationHigh'],row['Namespace'],row["UnitLow"])
                    
    except Exception as e:
        logger.error(e)