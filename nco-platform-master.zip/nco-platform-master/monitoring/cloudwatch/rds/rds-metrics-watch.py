import json
import boto3
import logging
import datetime
import os
from datetime import datetime, timedelta

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def get_alarm(alarm_name):
    try:    
        cloudwatch = boto3.client('cloudwatch')
        response = cloudwatch.describe_alarms(
        AlarmNames=[
            alarm_name,
        ]
        )
        return response
    except Exception as e:
        logger.error(e)
    

def get_rds_instance_list():    
    try:
        client = boto3.client('rds')
        rds_instances=client.describe_db_instances()
        return rds_instances
    except Exception as e:
        logger.error(e)

def create_rds_alarm(instance_identifier, metric_name,threshold_type,threshold,period_time,evaluation_periods_terms,namespace,statistic): 
    try:
        cloudwatch = boto3.client('cloudwatch')
        alarm_name="RDS-"+threshold_type+"-"+metric_name+"-"+instance_identifier+"-Alarm"
        response = get_alarm(alarm_name)
        if len (response['MetricAlarms']) == 0 or response['MetricAlarms'][0]['Threshold'] != threshold or response['MetricAlarms'][0]['Period'] != period_time:
            comparison_operator="LessThanOrEqualToThreshold"
            if threshold_type == "ThresholdHigh":
                comparison_operator="GreaterThanOrEqualToThreshold"
            
            cloudwatch.put_metric_alarm(
            AlarmDescription="Alarm when server "+metric_name+" exceeds threshold :",
            AlarmName=alarm_name,
            ActionsEnabled=True,
            MetricName=str(metric_name),
            AlarmActions=[
               os.environ['SNS_ARN']
            ],
            Namespace=namespace,
            Period=period_time,
            Statistic=statistic,
            EvaluationPeriods=evaluation_periods_terms,
            Threshold=threshold,
            ComparisonOperator=comparison_operator,            
            Dimensions=[
             {
              'Name': 'DBInstanceIdentifier',
              'Value': instance_identifier
             }
            ]
            )
    except Exception as e:
        print e
        logger.error(e)

        
def trigger_handler(event, context):
    
    s3 = boto3.client('s3')
    obj = s3.get_object(Bucket=os.environ['S3_Bucket'], Key='lambda/metrics-json.json')
    all_merics = json.loads(obj['Body'].read())
    rds_list=get_rds_instance_list()
    for r in rds_list['DBInstances']:
        rds_metrics=all_merics['RDS_Metrics']
        for row in all_merics['RDS_Metrics']:
            if row['ExecuteHigh']:
                logger.info("For RDS node : %s DB Instance : creating cloud-watch %s alarm" %(r['DBInstanceIdentifier'],row[u'MetricsName']))
                logger.info("Threshold hight : %s" %(row[u'ThresholdHigh']))
                create_rds_alarm(r['DBInstanceIdentifier'],row['MetricsName'],'ThresholdHigh',row['ThresholdHigh'],row['PeriodHigh'],row['EvaluationHigh'],row['Namespace'],row['UnitHigh'])
            if row['ExecuteLow']:    
                logger.info("For RDS node : %s DB Instance : creating cloud-watch %s alarm" %(r['DBInstanceIdentifier'],row[u'MetricsName']))
                logger.info("Threshold Low : %s" %(row[u'ThresholdLow']))
                create_rds_alarm(r['DBInstanceIdentifier'],row['MetricsName'],'ThresholdLow',row['ThresholdLow'],row['PeriodLow'],row['EvaluationLow'],row['Namespace'],row['UnitLow'])
        