import json
import boto3
import logging
import datetime
import os
from datetime import datetime, timedelta
from distutils.version import  StrictVersion
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def create_tags_for_aws_resource(aws_region):    
    try:
        logger.info("Describe instance list for region : %s " %(aws_region))
        client = boto3.client('ec2',region_name=aws_region)
        instDict=client.describe_instances() 
        hostList = {}
        for r in instDict['Reservations']:
            for inst in r['Instances']:
                if inst['State']['Name'] == "running":
                    for tag in inst['Tags']:
                        if tag['Key'] == 'infrastructure-version':
                            infrastructure_value=tag['Value']
                            infrastructure_value=infrastructure_value.lstrip('v')
                            if StrictVersion(infrastructure_value) > StrictVersion("1.1.0"):
                                create_tag(inst['InstanceId'],inst['Tags'],inst['BlockDeviceMappings'],aws_region)
                                print('Tag created Successfully')
    except Exception as e:
        logger.error(e)

def create_tag(instanceId,instanceTags,awsResource,aws_region):
    try:

        client = boto3.client('ec2',region_name=aws_region)
        if len(awsResource) > 0:
            for resource in awsResource:
                resourceId=resource['Ebs']['VolumeId']
                resourceTags=[]
                if len(instanceTags) > 0:
                    for tag in instanceTags:
                        if tag['Key']=='billing-category' or tag['Key']=='billing-subcategory' or tag['Key']=='infrastructure-version' or tag['Key']=='contact' or tag['Key']=='environment' or tag['Key']=='project' or tag['Key']=='service' or tag['Key']=='stack-identifier' or tag['Key']=='Name' or tag['Key']=='staging':
                            data={"Key":tag['Key'],"Value":tag['Value']}
                            resourceTags.append(data)
                    client.create_tags(Resources = [resourceId ],Tags= resourceTags)
                    logger.info("Created tag for volume : %s for instance id : %s " %([resourceId],instanceId))
                    logger.info("Tag values are : %s " %(resourceTags))

    except Exception as e:
        logger.error(e)
        
def trigger_handler(event, context):
    try:   
        regions = ["us-east-1","eu-west-1","eu-west-2","eu-central-1","us-east-2","us-west-1","us-west-2","ap-south-1","ap-northeast-1","ap-northeast-2","ap-southeast-1","ap-southeast-2","sa-east-1"]
        for i,region in enumerate(regions):
            create_tags_for_aws_resource(region)
            
    except Exception as e:
        logger.error(e)