#!/bin/bash -e

REGION=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep 'region'| awk '{print $3}' | sed 's/\"//g' | sed 's/\,//g' | tr -d '\n')
instance_id=`curl http://169.254.169.254/latest/meta-data/instance-id`
private_ip=`curl http://169.254.169.254/latest/meta-data/local-ipv4/`

# Set hostname
customer_name_abbreviation=$(echo -n "${STACK_NAME}" | awk -F "-" '{print $1}' | cut -c1-4)
jenkins_build_id=$(echo ${STACK_NAME} | awk -F "-" '{print $2}')
private_ip_with_dash=$(echo $private_ip | sed 's/\./-/g' )
region=$(echo ${STACK_REGION} | cut -c1-4 | tr -d "-")
MACHINE_HOSTNAME="$customer_name_abbreviation-${STACK_ENVIRONMENT}-bastion-$jenkins_build_id-$private_ip_with_dash-$region"

# This function use for wait until finish apt-get process
finish_process()
{
    while sudo fuser /var/lib/dpkg/lock >/dev/null 2>&1; do
       echo "wait 1 second for finish apt-get process"
       sleep 1
    done
}

# Install userify
curl -1 -sSk "https://userify.nuxeo.com/installer.sh" | \
    api_key="${USERIFY_KEY}" \
    api_id="${USERIFY_ID}" \
    company_name="Nuxeo" \
    project_name="${USERIFY_PROJ}" \
    static_host="userify.nuxeo.com" \
    shim_host="userify.nuxeo.com" \
    self_signed=1 \
    sudo -sE

finish_process

sleep 30

#INSTALL AND ACTIVATE
if [ ! -d /etc/dd-agent ]; then
    rm -rf /opt/datadog-agent
    DD_API_KEY=${DATADOG_APIKEY} bash -c "$(curl -L https://raw.githubusercontent.com/DataDog/dd-agent/master/packaging/datadog-agent/source/install_agent.sh)"
    service datadog-agent start
fi

DATDOG_FIRST_NAME=$(echo "${STACK_NAME}" | sed 's/.*/\u&/')
DATADOG_DASHBOARD_NAME="$DATDOG_FIRST_NAME-${STACK_ENVIRONMENT}"

if [[ ${STACK_ENVIRONMENT} == "prod" ]];then
    names_array=$(echo ${STACK_NAME} | tr "-" "\n")
    DATADOG_DASHBOARD_NAME=$(echo $names_array | awk '{print $1}'| sed 's/.*/\u&/')
fi  

CUSTOMER_BUCKET_HASH=`echo -n "${STACK_NAME}" | awk -F "-" '{print $1}' | tr -d '\n' | sha1sum | awk '{print $1}' | cut -c1-10`

cat << EOF > /etc/profile.d/nuxeo-env.sh
export STACK_NAME=${STACK_NAME}
export STACK_ENVIRONMENT=${STACK_ENVIRONMENT}
export CUSTOMER_BUCKET="nuxeo-configs-$CUSTOMER_BUCKET_HASH"
export NCO_VERSION=${NCO_VERSION}
export DATADOG_API_KEY=${DATADOG_APIKEY}
export DATADOG_APP_KEY=${DATADOG_APPKEY}
export MACHINE_HOSTNAME="$MACHINE_HOSTNAME"
export DATADOG_DASHBOARD_NAME="$DATADOG_DASHBOARD_NAME"
EOF

aws s3 cp s3://nuxeo-platform/userdata/${NCO_VERSION}/bastion-script/ /opt/nuxeo-platform/scripts/ --recursive

bash /opt/nuxeo-platform/scripts/nuxeo_bastion_userdata.sh

service datadog-agent restart

echo "User data scipt run completed"