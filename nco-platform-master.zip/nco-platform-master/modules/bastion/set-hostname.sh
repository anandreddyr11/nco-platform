#!/bin/bash -e

set -e

if [ -d "/opt/nuxeo-ansible/ansible/nco-platform" ]; then

cd /etc/profile.d/

. ./nuxeo-env.sh

instance_id=`curl http://169.254.169.254/latest/meta-data/instance-id`

region=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep 'region'| awk '{print $3}' | sed 's/\"//g' | sed 's/\,//g' | tr -d '\n')

aws ec2 create-tags --resources ${instance_id} --tags Key=Name,Value=${MACHINE_HOSTNAME} --region ${region}

fi