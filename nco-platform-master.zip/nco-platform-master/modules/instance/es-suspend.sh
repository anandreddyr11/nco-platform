#!/bin/bash -e

set -e

################################################################################
# File:    es-suspend.sh
# Purpose: Suspend ES Autoscaling
# Version: 0.1
# Author:  Jai Bapna
# Created: 2017-06-13
################################################################################

echo "BLUE_MIN_COUNT : ${BLUE_MIN_COUNT}"
echo "GREEN_MIN_COUNT : ${GREEN_MIN_COUNT}"
echo "BLUE_ASG NAME : ${BLUE_ASG}"
echo "GREEN_ASG NAME : ${GREEN_ASG}"
echo "AWS REGION : ${AWS_REGION}"


if [ "$BLUE_MIN_COUNT" -eq 0 ];then
echo "BLUE_MIN_COUNT is zero"
aws autoscaling resume-processes --auto-scaling-group-name ${BLUE_ASG} --region ${AWS_REGION}
fi

if [ "$GREEN_MIN_COUNT" -eq 0 ];then
echo "GREEN_MIN_COUNT is zero"
aws autoscaling resume-processes --auto-scaling-group-name ${GREEN_ASG} --region ${AWS_REGION}
fi	