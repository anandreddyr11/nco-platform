# Release Notes - v1.1.1

- Golden AMIs 

[Nuxeo 8.10 ES version 2.3.5]

Region  | nuxeo-v1.1.0-app-8.10-generic-09-08-17-14-27-57|nuxeo-v1.1.0-es-8.10-generic-09-08-17-13-39-52|nuxeo-v1.1.0-bastion-8.10-generic-09-08-17-12-59-21
  ----------------| -------------|---------------|------------
 ap-northeast-1   | ami-2516d043 |ami-c80accae | ami-830ccae5
  ap-northeast-2  | ami-bcd60dd2 |ami-28d50e46 | ami-a5d70ccb 
  ap-south-1      | ami-8e5413e1 |ami-4a541325 | ami-835611ec 
  ap-southeast-1  | ami-ba8de4d9 |ami-12b4dd71 | ami-9eb3dafd 
  ap-southeast-2  | ami-4635d124 |ami-222ace40 | ami-0429cd66 
  ca-central-1    | ami-80f44de4 |ami-6df44d09 | ami-a5f34ac1 
  eu-central-1    | ami-223a8e4d |ami-fc388c93 | ami-9b3e8af4 
  eu-west-1       | ami-f0f13789 |ami-b2f630cb | ami-0be82e72 
  eu-west-2       | ami-6a54470e |ami-105b4874 | ami-b45a49d0 
  sa-east-1       | ami-d36012bf |ami-127d0f7e | ami-6b631107
  us-east-1       | ami-5eeff325 |ami-adf6ead6 | ami-e9ffe392 
  us-east-2       | ami-f7557792 |ami-6c577509 | ami-10567475 
  us-west-1       | ami-b50532d5 |ami-32053252 | ami-65073005
  us-west-2       | ami-f88c7a80 |ami-5380762b | ami-c68472be 

[Nuxeo 9.2 ES version 2.4.6]

Region  | nuxeo-v1.1.1-app-9.2-generic-09-11-17-23-11-21| nuxeo-v1.1.1-es-9.2-generic-09-12-17-18-30-24 | nuxeo-v1.1.0-bastion-8.10-generic-09-08-17-12-59-21
----------------| -------------|---------------|------------
ap-northeast-1  | ami-037aba65 | ami-66ed2e00  | ami-830ccae5
ap-northeast-2  | ami-62e13a0c | ami-301bc05e  | ami-a5d70ccb
ap-south-1      | ami-4dabec22 | ami-1ac78075  | ami-835611ec
ap-southeast-1  | ami-3fb4df5c | ami-77325814  | ami-9eb3dafd
ap-southeast-2  | ami-cab651a8 | ami-fc9c7b9e  | ami-0429cd66
ca-central-1    | ami-6ada630e | ami-07de6763  | ami-a5f34ac1
eu-central-1    | ami-3d932452 | ami-eb7ec984  | ami-9b3e8af4
eu-west-1       | ami-0f814176 | ami-1cf53565  | ami-0be82e72
eu-west-2       | ami-69796a0d | ami-36667552  | ami-b45a49d0
sa-east-1       | ami-b09feddc | ami-7cf48610  | ami-6b631107
us-east-1       | ami-3e180345 | ami-54d2c82f  | ami-e9ffe392
us-east-2       | ami-9d3f1df8 | ami-9c0426f9  | ami-10567475
us-west-1       | ami-73af9813 | ami-2d84b34d  | ami-65073005
us-west-2       | ami-3818e940 | ami-7fa35307  | ami-c68472be
  


- All v1.1.1 stack operations are handled by jobs in the v1.1.1 Jenkins tab [https://deploy.nuxeocloud.com/view/v1.1.1/]

- During stack provisioning, we use ANSIBLE for bootstrapping the instances. Ansible currently installs:     
Nuxeo App <br />
Nuxeo Packages  <br />
Elasticsearch   <br />
Elasticsearch Plugin  <br />
Java <br />
AWS Cli  <br />
Other development tools <br />
