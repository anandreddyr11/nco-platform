#!/bin/bash -e

set -e

ABSOLUTE_PATH=$(cd `dirname "${BASH_SOURCE[0]}"` && pwd)

terraform version

[ -d ${CUSTOMER}/${ENVIRONMENT} ]

echo "**************************************************"
echo "Configure Terraform Variables"
echo "**************************************************"

MODULE_NAME="stack"

sed -i  "/STACK_NAME /c\STACK_NAME = \"${UPDATE_CUSTOMER}\" " ${CUSTOMER}/${ENVIRONMENT}/terraform.tfvars

sed -i  "/STACK_URL /c\STACK_URL = \"${UPDATE_CUSTOMER}-${ENVIRONMENT}.nuxeocloud.com\" " ${CUSTOMER}/${ENVIRONMENT}/terraform.tfvars

VPC_ID=$(aws ec2 describe-instances --filters "Name=instance-state-name,Values=running" "Name=tag:aws:autoscaling:groupName,Values=*${UPDATE_CUSTOMER}-${ENVIRONMENT}-nuxeo*" "Name=tag:project,Values=${CUSTOMER}" --region ${AWS_REGION} --output text --query "Reservations[0].Instances[0].VpcId")

VPC_NAME=$(aws ec2 describe-vpcs --vpc-ids ${VPC_ID} --region ${AWS_REGION}  --output text --query "Vpcs[].{name: Tags[?Key=='Name'] |  [0].Value}")

cat <<EOF >> ${CUSTOMER}/${ENVIRONMENT}/terraform.tfvars

VPC_NAME = "${VPC_NAME}"
 
EOF

cd ${CUSTOMER}/${ENVIRONMENT}

aws s3 cp terraform.tfvars s3://nuxeo-platform/tfstate/customers/${NCO_RELEASE}/${CUSTOMER}/${AWS_REGION}/${ENVIRONMENT}/${UPDATE_CUSTOMER}/terraform.tfvars


echo "**************************************************"
echo "Get Terraform Templates to build Customer"
echo "**************************************************"

cp -R ${MODULE_PATH}/nco-platform nuxeo-terraform-modules

terraform init -no-color \
  -backend=true \
  -backend-config="bucket=nuxeo-platform" \
  -backend-config="key=tfstate/customers/${NCO_RELEASE}/${CUSTOMER}/${AWS_REGION}/${ENVIRONMENT}/${UPDATE_CUSTOMER}/terraform.tfstate" \
  -backend-config="region=us-east-1" \
   nuxeo-terraform-modules/templates/${MODULE_NAME}

echo "**************************************************"
echo "Get Terraform Modules"
echo "**************************************************"

terraform get -no-color -update

## Fetch remote state if existent
terraform refresh -no-color

## Plan execution
terraform plan -no-color -out ${CUSTOMER}-${ENVIRONMENT}.plan

## Provision
terraform apply -no-color

#Copy state file for backup
aws s3 cp s3://nuxeo-platform/tfstate/customers/${NCO_RELEASE}/${CUSTOMER}/${AWS_REGION}/${ENVIRONMENT}/${UPDATE_CUSTOMER}/terraform.tfstate s3://nuxeo-platform/tfstate_backup/customers/${NCO_RELEASE}/${CUSTOMER}/${AWS_REGION}/${ENVIRONMENT}/${UPDATE_CUSTOMER}/terraform.tfstate