#!/bin/bash -e

set -ex

ABSOLUTE_PATH=$(cd `dirname "${BASH_SOURCE[0]}"` && pwd)

terraform version

[ -d ${CUSTOMER}/${ENVIRONMENT} ]

echo "**************************************************"
echo "Configure Terraform Variables"
echo "**************************************************"

AWS_REGION=$(cat ${CUSTOMER}/${ENVIRONMENT}/terraform.tfvars  |  grep REGION | awk -F'=' '{print $2}' | tr -d '" ')

MODULE_NAME="stack"

sed -i  "/STACK_NAME /c\STACK_NAME = \"${UPDATE_CUSTOMER}\" " ${CUSTOMER}/${ENVIRONMENT}/terraform.tfvars

sed -i  "/STACK_URL /c\STACK_URL = \"${UPDATE_CUSTOMER}-${ENVIRONMENT}.nuxeocloud.com\" " ${CUSTOMER}/${ENVIRONMENT}/terraform.tfvars

cat <<EOF >> ${CUSTOMER}/${ENVIRONMENT}/terraform.tfvars

VPC_NAME = "${VPC_NAME}"
 
EOF

cd ${CUSTOMER}/${ENVIRONMENT}

STACK_ENVIRONMENT=$(cat terraform.tfvars | grep STACK_ENVIRONMENT | awk -F "=" '{print $2}' | sed 's/\"//g' |  sed 's/ //g'  | tr -d "\n")

if [[ ! "${STACK_ENVIRONMENT}" ]];then
  echo "STACK_ENVIRONMENT variables not found in TF file"
  exit 1
fi

aws s3 cp terraform.tfvars s3://nuxeo-platform/tfstate/customers/${NCO_RELEASE}/${CUSTOMER}/${AWS_REGION}/${STACK_ENVIRONMENT}/${UPDATE_CUSTOMER}/terraform.tfvars

echo "**************************************************"
echo "Get Terraform Templates to build Customer"
echo "**************************************************"

cp -R ${MODULE_PATH}/nco-platform nuxeo-terraform-modules

test -f Makefile && make clean

terraform init -no-color \
  -backend=true \
  -backend-config="bucket=nuxeo-platform" \
  -backend-config="key=tfstate/customers/${NCO_RELEASE}/${CUSTOMER}/${AWS_REGION}/${STACK_ENVIRONMENT}/${UPDATE_CUSTOMER}/terraform.tfstate" \
  -backend-config="region=us-east-1" \
   nuxeo-terraform-modules/templates/${MODULE_NAME}

echo "**************************************************"
echo "Get Terraform Modules"
echo "**************************************************"


terraform get -no-color -update

## Fetch remote state if existent
terraform refresh -no-color

## Plan execution
terraform plan -no-color -out ${CUSTOMER}-${STACK_ENVIRONMENT}.plan

## Provision
terraform apply -no-color

#Copy state file for backup
aws s3 cp s3://nuxeo-platform/tfstate/customers/${NCO_RELEASE}/${CUSTOMER}/${AWS_REGION}/${STACK_ENVIRONMENT}/${UPDATE_CUSTOMER}/terraform.tfstate s3://nuxeo-platform/tfstate_backup/customers/${NCO_RELEASE}/${CUSTOMER}/${AWS_REGION}/${STACK_ENVIRONMENT}/${UPDATE_CUSTOMER}/terraform.tfstate