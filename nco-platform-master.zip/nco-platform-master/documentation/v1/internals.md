# Philosophy 
This library of terraform modules follows the deployment model described on the image below
![pipeline](./pipeline.png)

Each terraform module constitutes the code to deploy a resource or combination of resources
to be provisioned.

The modules are combined in templates to agregate different type of intended deployments or architectures.


 ![workflow](https://github.com/nuxeo/nuxeo-terraform-modules/raw/master/workflow.png)

To provision the resources, a provider is required to create those resources, such as AWS for network,
computing or storage. There are other providers used such as Datadog, Cloudinit or others like Docker
Hashicorp Consul and Vault (that might be include in future version of this repo).

# Cloud Architecture


## Topology 

The cloud architecture is supposed to be multi-region. This implies that, each region must be deployed
in separate, and the for the moment each region corresponds to a single VPC.


 ![topology](https://github.com/nuxeo/nuxeo-terraform-modules/raw/master/topology.png)

##  Region 

A region architecture is composed a VPC plus all fundamental components to make it ready to deploy tenants, 
such as an Internet Gateway, a NAT Gateway, an EIP address, couple of supporting subnets private and public, 
bastion host, routes, security groups.

This is what is considered a golden base for the region (see [AWS goldbase](https://d0.awsstatic.com/events/aws-hosted-events/2015/WWPS/Miscellaneous/Introduction_to_GoldBase.pdf))


 ![region](https://github.com/nuxeo/nuxeo-terraform-modules/raw/master/region-architecture.png)

## Multi-Tenants

Due to known limitations of the number of VPC per account and also subnets, the following diagram shows
how a tenant is put on the same VPC/Region, isolated by subnets, security groups and separated resources.


 ![multi-tenants](https://github.com/nuxeo/nuxeo-terraform-modules/raw/master/region-architecture-tenants.png)

# Tenant - Standard

A typical tentant deployment is described in the following diagram.

Different combination of deployments can be constructed in the templates section, see [templates](./templates)
 ![tenant standard](https://github.com/nuxeo/nuxeo-terraform-modules/raw/master/customer-standard.png)

# Structure of this Libray

This repo includes follows a structure to separate the modules from its usage on templates, 
as described in the diagram with the following 

![components](https://github.com/nuxeo/nuxeo-terraform-modules/raw/master/components.png)

## Repository Directory Structure:

- *modules* - folder where resources or combination of resources are declared
    - alb - AWS Application Load Balancer
    - asg - AWS Auto Scaling Group (not ready/used)
    - bastion - Bastion host
    - defaults - default global variables
    - dns - AWS Route 53
    - ebs - AWS Elastic Block Storage
    - ecr - AWS EC2 Container Registry (not ready/used)
    - efs - AWS Elastic File System
    - elasticcache - AWS Redis
    - instance - AWS EC2 instance with ALB
    - instance_asg_alb - AWS EC2 instance with Auto Scaling Group (not ready/used)
    - rds - AWS RDS Posgtresql database
    - s3 - AWS S3 Bucket for Binstores and Backup
    - subnet - AWS Subnet
    - vpc - AWS Virtual Private Cloud
- *templates* - this folder creates templates to be used with terraform init which 
gets copied to be used to deploy different types of architecture, which combines in different ways the modules.

Additionally the following folders are  used for support functions:

- *ci* - here are building scripts to be used on Jenkins. Test scripts should be also be put here
- *packer* - scripts to create images, such as AWS AMI or Docker images

To be used in the future to deploy in each Cloud or globally to manage all infrastructure:

- *management* - TBD (initially planned for cloud management resources such as CI, Orchestration and Secrets Management)
