#!/bin/bash

################################################################################
#                                  SETTINGS                                    #
################################################################################
################################################################################
#                                  SETTINGS                                    #
################################################################################
source /etc/profile.d/nuxeo-env.sh

DEBUG=false

ANSIBLE_DIR="/opt/nuxeo-ansible/ansible"

# binaries
ECHO="/bin/echo -e"
HOSTNAME="/bin/hostname"
MKDIR="/bin/mkdir"
MV="/bin/mv"
RM="/bin/rm -rf"
TAR="/bin/tar"
CUT="/bin/cut"
GREP="/bin/grep"
REV="/usr/bin/rev"
AWS="/usr/bin/aws"

################################################################################
#                                  FUNCTIONS                                   #
################################################################################

################################################################################
# Name:    debug
# Purpose: Prints debug messages if the DEBUG flag is enabled
# Input:   msg - Message to be printed
# Output:  nothing returned, but msg printed to STDOUT
################################################################################
function debug {

        if [ "$DEBUG" = true ]; then
                $ECHO $1
        fi

}

################################################################################
#                                  MAIN BODY                                   #
################################################################################

# DECLARE VARIABLES

ANSIBLE_ENV="${STACK_ENVIRONMENT}"
ANSIBLE_PLAYBOOK="security_updates"

####################
# HANDLE ARGUMENTS #
####################
while getopts ":jdv:," opt; do
        case $opt in
                v)
                        VERSION=$OPTARG
                        ;;
                d)
                        DEBUG=true
                        ;;
                \?)
                        $ECHO "Invalid option: -$OPTARG"
                        exit 1
                        ;;
                :)
                        $ECHO "Option -$OPTARG requires an argument."
                        exit 1
                ;;
        esac
done

cd $ANSIBLE_DIR

# did the user specify a version number as an argument?
if [[ ! -z "$VERSION" ]]; then
        # the user specified a version number; let's just use that
        $ECHO "VERSION=$VERSION" > "$ANSIBLE_ENV.latest-new"

else
        # the user did not specify a version number; get it from s3 .latest file

         # attempt to get the version number from a role-specific .latest file in s3
        result=`$AWS s3 cp "s3://${CUSTOMER_BUCKET}/ansible/$ANSIBLE_PLAYBOOK.latest" "$ANSIBLE_ENV.latest-new" 2>&1`

        # did the attempt to download a role-specific .latest file fail?
        if [[ $? -ne 0 || `$ECHO "$result" | $GREP "S3 command failed"` ]]; then
                # it failed; fall-back on the environment-specific .latest file

                # get the version number from the environment .latest file in s3
                $ECHO "retrieving version # from ${CUSTOMER_BUCKET}/ansible/$ANSIBLE_ENV.latest"
                result=`$AWS s3 cp "s3://${CUSTOMER_BUCKET}/ansible/$ANSIBLE_ENV.latest" "$ANSIBLE_ENV.latest-new" 2>&1`

                # did the attempt to download the environment .latest file fail?
                if [[ $? -ne 0 || `$ECHO "$result" | $GREP "S3 command failed"` ]]; then
                        # it failed; exit with error
                        $ECHO "ERROR: Failed to get VERSION. Could not download .latest file"
                        exit 1
                fi
        fi

fi

source "$ANSIBLE_DIR/$ANSIBLE_ENV.latest-new"
NEW_VERSION=$VERSION


if [ -e $ANSIBLE_ENV.latest ]; then

  source "$ANSIBLE_DIR/$ANSIBLE_ENV.latest"
  OLD_VERSION=$VERSION
  
else
  OLD_VERSION="NONE"
fi

if [[ "$OLD_VERSION" != "$NEW_VERSION" ]]; then

        $ECHO "installing $NEW_VERSION"
        $ECHO "retrieving ${CUSTOMER_BUCKET}:ansible/ansible.$NEW_VERSION.tar.gz from s3"
        $AWS s3 cp s3://${CUSTOMER_BUCKET}/ansible/ansible.nuxeo.$NEW_VERSION.tar.gz provisioning.tar.gz || exit 1


        $ECHO "removing Provisiong-old"
        $RM Provisioning-old || exit 1


        if [[ -d Provisioning ]];then
           $MV Provisioning Provisioning-old || exit 1
        fi


        $ECHO "making Provisioning & untaring provisioning.tar.gz into it"
        if [ -f provisioning.tar.gz ] && [ ! -d Provisioning ]; then
                $MKDIR Provisioning || exit 1
                cd Provisioning
                $TAR xzf "$ANSIBLE_DIR/provisioning.tar.gz" || exit 1
        else
                $ECHO "[ERROR] problem with tar.gz file"
                exit 1
        fi
        $MV "$ANSIBLE_DIR/$ANSIBLE_ENV.latest-new" "$ANSIBLE_DIR/$ANSIBLE_ENV.latest" || exit 1

else

        $ECHO "version # $OLD_VERSION is same as already installed exiting now"
        $RM "$ANSIBLE_DIR/$ANSIBLE_ENV.latest-new" || exit 1
        exit 1

fi


ROLE_JSON_FILE=$ANSIBLE_PLAYBOOK.yml

echo "yml file to use $ROLE_JSON_FILE"

cd "$ANSIBLE_DIR/Provisioning"

bash provision_ansible.sh $ROLE_JSON_FILE || exit 1

# exit cleanly
exit 0
