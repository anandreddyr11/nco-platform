#!/bin/bash -e

set -e

################################################################################
# File:    nuxeo_worker_userdata.sh
# Purpose: This Script run as userdata for worker Dedicate node
# Version: 0.1
# Author:  Jai Bapna
# Created: 2017-06-14
################################################################################

LOG_FILE=/var/log/nuxeo-worker-userdata.log

exec > >(tee -a ${LOG_FILE} )
exec 2> >(tee -a ${LOG_FILE} >&2)

source /etc/profile.d/nuxeo-env.sh

ABSOLUTE_PATH=$(cd `dirname "${BASH_SOURCE[0]}"` && pwd)/
echo $ABSOLUTE_PATH
REGION=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep 'region'| awk '{print $3}' | sed 's/\"//g' | sed 's/\,//g' | tr -d '\n')

# Copy ssh key
aws s3 cp s3://nuxeo-platform/ssh-keys/ /opt/nuxeo-platform/scripts/keys/ --recursive

# Permission root user for ssh
bash ${ABSOLUTE_PATH}configure_root_user.sh


# Run create datadog dashboard script
# bash ${ABSOLUTE_PATH}worker_datadog_dashboard.sh

#Run Cloudwatch matrics scripts
cd /opt
wget https://s3.amazonaws.com/nuxeo-platform/lambda/install-cw.sh
bash install-cw.sh

apt-get -y update

# Configure ansible cron
mkdir -p /opt/nuxeo-ansible/ansible/nco-platform
cd /opt/nuxeo-ansible/ansible/nco-platform
aws s3 cp s3://nco-platform-releases/${NCO_VERSION}/${NCO_VERSION}-release/nco-platform.tar.gz nco-platform.tar.gz
tar -xvzf nco-platform.tar.gz
export HOME=/root
ANSIBLE_FORCE_COLOR=1 PYTHONUNBUFFERED=1 ansible-playbook  -i "localhost"  -c local  ansible/nuxeo_worker.yml --extra-vars "AWS_REGION=${REGION}"

cp ${ABSOLUTE_PATH}provisioning_ansible_updater.sh /opt/nuxeo-ansible/ansible/provisioning_ansible_updater.sh
sed -i  "/#log_path/c\log_path = /opt/nuxeo-ansible/ansible/Provisioning/ansible.log" /etc/ansible/ansible.cfg

if  ! crontab -l | grep -q "/opt/nuxeo-ansible/ansible/provisioning_ansible_updater.sh"
then
crontab -l | { cat; echo "*/5 * * * * sudo /bin/bash  /opt/nuxeo-ansible/ansible/provisioning_ansible_updater.sh >> /var/log/ansible.log 2>&1"; } | crontab -
fi