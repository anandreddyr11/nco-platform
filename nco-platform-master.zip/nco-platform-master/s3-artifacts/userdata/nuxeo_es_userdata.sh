#!/bin/bash -e

set -e

################################################################################
# File:    nuxeo_es_userdata.sh
# Purpose: This Script run as userdata for ES Dedicate node
# Version: 0.1
# Author:  Jai Bapna
# Created: 2017-06-14
################################################################################

LOG_FILE=/var/log/nuxeo-es-userdata.log

exec > >(tee -a ${LOG_FILE} )
exec 2> >(tee -a ${LOG_FILE} >&2)

source /etc/profile.d/nuxeo-env.sh

ABSOLUTE_PATH=$(cd `dirname "${BASH_SOURCE[0]}"` && pwd)/
echo $ABSOLUTE_PATH
REGION=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep 'region'| awk '{print $3}' | sed 's/\"//g' | sed 's/\,//g' | tr -d '\n')
INSTANCE_ID=$(curl http://169.254.169.254/latest/meta-data/instance-id)

# Copy ssh key
aws s3 cp s3://nuxeo-platform/ssh-keys/ /opt/nuxeo-platform/scripts/keys/ --recursive

# Permission root user for ssh
bash ${ABSOLUTE_PATH}configure_root_user.sh

# Set elasticsearch heapsize
heap_size=$(dmidecode -t 17 | grep "Size.*MB" | awk '{s+=$2} END {print s / 1024}' | awk '{print $1/2}')
total_size=$( printf "%.0f" $heap_size )
ES_HEAP_SIZE=$(($total_size + 1))

if [ "$ES_HEAP_SIZE" -gt "32" ];then
ES_HEAP_SIZE=32
fi

export ES_HEAP_SIZE=$ES_HEAP_SIZE
cat << EOF > /etc/profile.d/elasticsearch-env.sh
export ES_HEAP_SIZE=$ES_HEAP_SIZE
EOF

node_type=$(aws ec2 describe-tags --filters "Name=resource-id,Values=${INSTANCE_ID}" "Name=key,Values=aws:autoscaling:groupName" --region ${REGION} --output=text | cut -f5 | rev | cut -d'-' -f 1 | rev )

es_sg_name=$([ "$node_type" == "blue" ] && echo "${STACK_NAME}-${STACK_ENVIRONMENT}-es-blue-sg" || echo "${STACK_NAME}-${STACK_ENVIRONMENT}-es-green-sg")

export SECURITY_GROUPS=${es_sg_name}
echo "export SECURITY_GROUPS=${es_sg_name}" >> /etc/profile.d/nuxeo-env.sh
source /etc/profile.d/nuxeo-env.sh

# Run create datadog dashboard script
#bash ${ABSOLUTE_PATH}es_datadog_dashboard.sh

#Run Cloudwatch matrics scripts
cd /opt
wget https://s3.amazonaws.com/nuxeo-platform/lambda/install-cw.sh
bash install-cw.sh

#apt-get -y update

# Configure ansible cron
mkdir -p /opt/nuxeo-ansible/ansible/nco-platform
cd /opt/nuxeo-ansible/ansible/nco-platform
aws s3 cp s3://nco-platform-releases/${NCO_VERSION}/${NCO_VERSION}-release/nco-platform.tar.gz nco-platform.tar.gz
tar -xvzf nco-platform.tar.gz
export HOME=/root
ANSIBLE_FORCE_COLOR=1 PYTHONUNBUFFERED=1 ansible-playbook  -i "localhost"  -c local  ansible/nuxeo_es.yml --extra-vars "AWS_REGION=${REGION}"

cp ${ABSOLUTE_PATH}provisioning_ansible_updater.sh /opt/nuxeo-ansible/ansible/provisioning_ansible_updater.sh
sed -i  "/#log_path/c\log_path = /opt/nuxeo-ansible/ansible/Provisioning/ansible.log" /etc/ansible/ansible.cfg

if  ! crontab -l | grep -q "/opt/nuxeo-ansible/ansible/provisioning_ansible_updater.sh"
then
crontab -l | { cat; echo "*/5 * * * * sudo /bin/bash  /opt/nuxeo-ansible/ansible/provisioning_ansible_updater.sh >> /var/log/ansible.log 2>&1"; } | crontab -
fi