#!/bin/bash -e

set -e

################################################################################
# File:    nuxeo_es_address_list.sh
# Purpose: This Script use for add dedicate es host in /apps/nuxeo/conf/nuxeo.conf
# Version: 0.1
# Author:  Jai Bapna
# Created: 2017-06-14
# Run :    bash nuxeo_es_address_list.sh 
################################################################################

REGION=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep 'region'| awk '{print $3}' | sed 's/\"//g' | sed 's/\,//g' | tr -d '\n')
es_address_list=$(aws ec2 describe-instances --filters "Name=instance-state-name,Values=running"  "Name=tag:aws:autoscaling:groupName,Values=es-${STACK_NAME}-${STACK_ENVIRONMENT}*" "Name=tag:service,Values=elasticsearch" --region $REGION | jq -r '.Reservations[].Instances[].PrivateIpAddress' | sed ':a;N;$!ba;s/\n/:9300,/g' | sed 's/.*/&:9300/')
sed -i "/^#/!s/elasticsearch.addressList.*/elasticsearch.addressList=${es_address_list}/g" /apps/nuxeo/conf/nuxeo.conf