#!/bin/bash -e

set -e

################################################################################
# File:    configure_root_user.sh
# Purpose: This script use for ssh enable for root user and copy ssh key
# Version: 0.1
# Author:  Jai Bapna
# Created: 2017-06-14
################################################################################

BUCKET_NAME="nuxeo-platform"

sed -i  "/PermitRootLogin/c\PermitRootLogin yes" /etc/ssh/sshd_config
sed -i  "/#   StrictHostKeyChecking/c\    StrictHostKeyChecking no" /etc/ssh/ssh_config

cp /opt/${BUCKET_NAME}/scripts/keys/platform.pub /root/.ssh/authorized_keys 

/etc/init.d/ssh restart