#!/bin/bash -e

set -e

################################################################################
# File:    nuxeo_userdata.sh
# Purpose: This Script run as userdata for ES Dedicate node
# Version: 0.1
# Author:  Jai Bapna
# Created: 2017-06-14
################################################################################

LOG_FILE=/var/log/nuxeo-app-userdata.log

exec > >(tee -a ${LOG_FILE} )
exec 2> >(tee -a ${LOG_FILE} >&2)

source /etc/profile.d/nuxeo-env.sh

ABSOLUTE_PATH=$(cd `dirname "${BASH_SOURCE[0]}"` && pwd)/
echo $ABSOLUTE_PATH
REGION=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep 'region'| awk '{print $3}' | sed 's/\"//g' | sed 's/\,//g' | tr -d '\n')

# Copy backup script
aws s3 cp s3://nuxeo-platform/ssh-keys/ /opt/nuxeo-platform/scripts/keys/ --recursive
cp /opt/nuxeo-platform/scripts/keys/platform /root/.ssh/platform
chmod 600 /root/.ssh/platform

# Permission root user for ssh
bash ${ABSOLUTE_PATH}configure_root_user.sh

# Run create datadog dashboard script
# bash ${ABSOLUTE_PATH}app_datadog_dashboard.sh

#Run Cloudwatch matrics scripts
cd /opt
wget https://s3.amazonaws.com/nuxeo-platform/lambda/install-cw.sh
bash install-cw.sh

apt-get -y update

# Configure ansible cron
mkdir -p /opt/nuxeo-ansible/ansible/nco-platform
cd /opt/nuxeo-ansible/ansible/nco-platform
aws s3 cp s3://nco-platform-releases/${NCO_VERSION}/${NCO_VERSION}-release/nco-platform.tar.gz nco-platform.tar.gz
tar -xvzf nco-platform.tar.gz
export HOME=/root
ANSIBLE_FORCE_COLOR=1 PYTHONUNBUFFERED=1 ansible-playbook  -i "localhost"  -c local  ansible/nuxeo_app.yml --extra-vars "AWS_REGION=${REGION}"

cp ${ABSOLUTE_PATH}provisioning_ansible_updater.sh /opt/nuxeo-ansible/ansible/provisioning_ansible_updater.sh
sed -i  "/#log_path/c\log_path = /opt/nuxeo-ansible/ansible/Provisioning/ansible.log" /etc/ansible/ansible.cfg

if  ! crontab -l | grep -q "/opt/nuxeo-ansible/ansible/provisioning_ansible_updater.sh"
 then
 crontab -l | { cat; echo "*/5 * * * * sudo /bin/bash  /opt/nuxeo-ansible/ansible/provisioning_ansible_updater.sh >> /var/log/ansible.log 2>&1"; } | crontab -
fi


# Copy Customer specific files
set +e
set -x
CUSTOMER_NAME=$(echo ${STACK_NAME} | awk -F "-" '{print $1}')
CUSTOMER_NAME_HASH=$(echo -n "${CUSTOMER_NAME}" | sha1sum | awk '{print $1}' | cut -c1-10)
aws s3 ls s3://nuxeo-configs-${CUSTOMER_NAME_HASH}/${STACK_ENVIRONMENT}/configs/nuxeo.conf
if [ $? -eq 0 ]; then
 aws s3 cp s3://nuxeo-configs-${CUSTOMER_NAME_HASH}/${STACK_ENVIRONMENT}/configs/nuxeo.conf /apps/nuxeo/conf/nuxeo.conf
 chown nuxeo:nuxeo /apps/nuxeo/conf/nuxeo.conf
 chmod  0664 /apps/nuxeo/conf/nuxeo.conf
fi

aws s3 ls s3://nuxeo-configs-${CUSTOMER_NAME_HASH}/${STACK_ENVIRONMENT}/configs/nuxeo
if [ $? -eq 0 ]; then
 aws s3 cp s3://nuxeo-configs-${CUSTOMER_NAME_HASH}/${STACK_ENVIRONMENT}/configs/nuxeo /etc/apache2/sites-available/
 service apache2 restart
fi
set +x
set -e

# Add Elasticsearch Ips in /opt/nuxeo/conf/nuxeo.conf
if [ ${ES_DEDICATED} -eq 1 ]; then
bash ${ABSOLUTE_PATH}nuxeo_es_address_list.sh
fi

invoke-rc.d nuxeo start