form version

export REGION=${AWS_REGION}
cd ${REGION}


echo "----------------------------------"
echo "Build AWS VPC for region ${REGION}"
echo "----------------------------------"

echo "**************************************************"
echo "Get Terraform Templates to build Cloud VPC Region"
echo "**************************************************"
test -f Makefile && make clean
terraform init \
  -backend=s3 \
  -backend-config="bucket=nuxeo-cloud-aws-envs" \
  -backend-config="key=${REGION}/terraform.tfstate" \
  -backend-config="region=eu-west-1" \
   git@github.com:nuxeo/nuxeo-terraform-modules//templates/region
echo "**************************************************"
echo "Get Terraform Modules"
echo "**************************************************"

# Get remote modules
terraform get -update

# Create tfvars
echo "
REGION = \"${REGION}\"
CLOUD_NAME = \"vpc-customers\"
" > terraform.tfvars

echo "### tfvars ###"
cat terraform.tfvars
echo "##############"

## Fetch remote state if existent
terraform refresh

## Plan execution
terraform plan -out tf-${REGION}.plan
        
## Provision
terraform apply


