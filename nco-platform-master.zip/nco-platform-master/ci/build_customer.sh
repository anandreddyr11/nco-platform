#!/bin/bash -e

terraform version

export REGION=${AWS_REGION}
export STACK_NAME=${CUSTOMER}

[ -d ${REGION}/${STACK_NAME} ] || mkdir ${REGION}/${STACK_NAME}
cd ${REGION}/${STACK_NAME}

echo "**************************************************"
echo "Get Terraform Templates to build Customer"
echo "**************************************************"
test -f Makefile && make clean
terraform init \
  -backend=s3 \
  -backend-config="bucket=nuxeo-cloud-aws-envs" \
  -backend-config="key=${REGION}/${STACK_NAME}/terraform.tfstate" \
  -backend-config="region=eu-west-1" \
   git@github.com:nuxeo/nuxeo-terraform-modules//templates/standard
echo "**************************************************"
echo "Get Terraform Modules"
echo "**************************************************"
#echo -e  'y\n'|ssh-keygen -q -t rsa -N "" -f mykey

terraform get -update

#Check if VPC of that region exists
aws ec2 describe-vpcs --region=${REGION} --filter "Name=tag-key, Values=Name" --query 'Vpcs[*].Tags[?Key==`Name`].Value[]' --output text | grep "vpc-customers" || 
{ echo "######################################################"
  echo	" Cloud VPC does not exist in the Region $REGION} yet "    
  echo "######################################################"
  echo
  echo "Try to run first the following job to create the VPC:"
  echo        
  echo "https://qa.nuxeo.org/jenkins/job/Private/job/Cloud/job/terraform-test/"
  exit 1 
}

# Create tfvars
echo "
REGION = \"us-east-1\"
STACK_NAME = \"${STACK_NAME}\"
SUBNET_CIDRS = \"10.10.20.0/24,10.10.21.0/24\"
USERIFY_ID = \"xxxx\"
USERIFY_KEY = \"yyyy\"
USERIFY_PROJ = \"${STACK_NAME}\"
" > terraform.tfvars

## Fetch remote state if existent
terraform refresh

## Plan execution
terraform plan -out tf-${REGION}.plan
        
## Provision
terraform apply
